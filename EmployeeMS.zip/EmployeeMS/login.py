from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk  #pip install pillow
from tkinter import messagebox
import mysql.connector


def main():
    win=Tk()
    app=Login_window(win)
    win.mainloop()
                        #main class containing root is created which will work with self:

class Login_window:

    def __init__(self, root, canvas=None):

        self.root=root
        self.root.title("Login")
        self.root.geometry("1500x800+0+0")
        e = self.vieweid
                    #----------------backgroung Image is inserted:----------------

        self.bg=ImageTk.PhotoImage(file="/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/bgg.png")
        Lbl_bg=Label(self.root,image=self.bg)
        Lbl_bg.place(x=0,y=0)
                    #background Black frame is created:

        frame = Frame(self.root,bg="black")
        frame.place(x=540,y=170,width=340,height=450)

                #----------------image for login at top of frame is inserted:----------------

        img1=Image.open("/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/loginicon.png")
        img1=img1.resize((120,120),Image.ANTIALIAS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lbl_img1=Label(image=self.photoimage1,bg="black",borderwidth=0)
        lbl_img1.place(x=662,y=175,width=100,height=100)
                    #----------------get started lable----------------:

        get_str=Label(frame,text="Get Started",font=("times new roman",25,"bold"),fg="white",bg="black")
        get_str.place(x=104,y=110)

                        #----------------lable for username----------------:

        username=Label(frame,text="Eid",font=("times new roman",20,"bold","underline"),fg="white",bg="black",
                       relief=GROOVE)
        img2 = Image.open("/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/user2.png")
        img2 = img2.resize((24, 24), Image.ANTIALIAS)       #----------------icon image----------------
        self.photoimage2 = ImageTk.PhotoImage(img2)
        lbl_img2 = Label(image=self.photoimage2, bg="black",borderwidth=0)
        lbl_img2.place(x=695, y=337.5, width=24, height=24)
        username.place(x=50,y=165)
                    #----------------entry lable for username----------------:

        self.txtuser=ttk.Entry(frame,font=("times new roman",20,"bold"))
        self.txtuser.place(x=30,y=205,width=275)
        e=self.txtuser.get()
                        #----------------lable for password:----------------

        password = Label(frame, text="DOB", font=("times new roman", 20, "bold", "underline"), fg="white",
                         bg="black",relief=SUNKEN)
        img3 = Image.open("/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/pass.png")
        img3 = img3.resize((24, 24), Image.ANTIALIAS)      #----------------icon image----------------
        self.photoimage3 = ImageTk.PhotoImage(img3)
        lbl_img3 = Label(image=self.photoimage3, bg="black", borderwidth=0)
        lbl_img3.place(x=695, y=436, width=24, height=24)
        password.place(x=50, y=260)

                        #----------------entry for passsword----------------:

        self.pasuser = ttk.Entry(frame, font=("times new roman", 20, "bold"))
        self.pasuser.place(x=30, y=300, width=275)
                            #----------------login button functions----------------

        l_btn=Button(frame,text="Login Now",font="arial 20 bold",highlightbackground='grey',fg="red",relief=GROOVE,bd=2,
                     activebackground="red",command=self.login)
        l_btn.place(x=95,y=350,width=120,height=30)

                            #----------------login image----------------

        img4 = Image.open("/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/lb2.png")
        img4 = img4.resize((27, 27), Image.ANTIALIAS)
        self.photoimage4 = ImageTk.PhotoImage(img4)
        lbl_img4 = Label(image=self.photoimage4, bg="black", borderwidth=0)
        lbl_img4.place(x=760, y=522, width=27, height=27)


    def login(self):
        if self.txtuser.get() == "" or self.pasuser.get() == "":
            messagebox.showerror("Invalid Credentials","Please enter Username & Password")

        else:
            conn = mysql.connector.connect(host="localhost", user="root", password="123456",
                                           database="loginDetails")
            mycur = conn.cursor()
            mycur.execute("SELECT * FROM register WHERE email=%s AND password=%s",(
                                self.txtuser.get(),
                self.pasuser.get()
            ))
            row=mycur.fetchone()
            if row == None:
                messagebox.showerror("Error","Invaid Username & password")
            else:
                open_main=messagebox.askyesno("Login","Do you wank to login")
                if open_main > 0:
                    self.new_window=Toplevel(self.root)
                    self.app=Success(self.new_window)

                else:
                    if not open_main:
                        return
                conn.commit()
                conn.close()



class Success:

    def __init__(self, root, canvas=None):
        self.root=root
        self.root.title("Success")
        self.root.geometry("1500x800+0+0")


        lb1 = Label(self.root, text="Login Successful", font="Consolas 44 bold")
        lb1.place(x=350, y=200)

        self.bg = ImageTk.PhotoImage(file="/Users/ambikamalhotra/PycharmProjects/LOGIN_FORM/like.png")
        bg_lbl = Label(self.root, image=self.bg)
        bg_lbl.place(x=790, y=170,)







#--------------FORGOT PASSWORD-----------



#main function which will run whole program ius created:

if __name__ == '__main__':
    main()
