from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
import mysql.connector
from tkinter import messagebox


class Employee:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1450x800+0+0")
        self.root.title('Employee Management System')

        #variables

        self.var_dep=StringVar()
        self.var_did = StringVar()
        self.var_fname=StringVar()
        self.var_lname = StringVar()
        self.var_eid = StringVar()
        self.var_email = StringVar()
        self.var_phoneno = StringVar()
        self.var_salary = StringVar()
        self.var_aadharno = StringVar()
        self.var_dob = StringVar()
        self.var_doj = StringVar()
        self.var_address=StringVar()
        self.var_gender = StringVar()




        lbl_title=Label(self.root,text="EMPLOYEE MANAGEMENT SYSTEM",font=('times new roman',37,'bold'),fg='darkblue',bg='white')
        lbl_title.place(x=0,y=0,width=1450,height=50)

        img_logo=Image.open('/Users/ambikamalhotra/PycharmProjects/EmployeeMS/l.jpeg')
        img_logo=img_logo.resize((40,40),Image.ANTIALIAS)
        self.photo_logo=ImageTk.PhotoImage(img_logo)

        self.logo=Label(self.root,image=self.photo_logo)
        self.logo.place(x=340,y=5,width=40,height=40)

        img_1 = Image.open('/Users/ambikamalhotra/PycharmProjects/EmployeeMS/1.jpeg')
        img_1 = img_1.resize((480, 150), Image.ANTIALIAS)
        self.photo_1 = ImageTk.PhotoImage(img_1)

        self.pic1 = Label(self.root, image=self.photo_1)
        self.pic1.place(x=20, y=50, width=480, height=150)

        img_2 = Image.open('/Users/ambikamalhotra/PycharmProjects/EmployeeMS/1.jpeg')
        img_2 = img_2.resize((480, 150), Image.ANTIALIAS)
        self.photo_2 = ImageTk.PhotoImage(img_2)

        self.pic2 = Label(self.root, image=self.photo_2)
        self.pic2.place(x=500, y=50, width=480, height=150)

        img_3 = Image.open('/Users/ambikamalhotra/PycharmProjects/EmployeeMS/1.jpeg')
        img_3 = img_3.resize((480, 150), Image.ANTIALIAS)
        self.photo_3 = ImageTk.PhotoImage(img_2)

        self.pic3 = Label(self.root, image=self.photo_3)
        self.pic3.place(x=980, y=50, width=480, height=150)

        # Main frame

        Main_frame=Frame(self.root,bd=2,relief=RIDGE,bg='white')
        Main_frame.place(x=20,y=210,width=1400,height=560)

        #upperframe
        upper_frame = LabelFrame(Main_frame, bd=2, relief=RIDGE, bg='white',text="Add Employee Details",font=('times new roman',12,'bold'),fg='red')
        upper_frame.place(x=10, y=10, width=1375, height=250)

        # lables and entry fields

#eid
        lbl_eid = Label(upper_frame, text="Emp-id", font=('Arial', 12, 'bold'), fg='black')
        lbl_eid.grid(row=0, column=0, padx=2, sticky=W)

        txt_Empid=ttk.Entry(upper_frame,textvariable=self.var_eid,font=('Arial', 12, 'bold'))
        txt_Empid.grid(row=0,column=1,padx=2,pady=7)
#fname
        lbl_Fname = Label(upper_frame, text="First Name", font=('Arial', 12, 'bold'), fg='black')
        lbl_Fname.grid(row=1, column=0, padx=2, sticky=W)

        txt_fname = ttk.Entry(upper_frame, textvariable=self.var_fname,font=('Arial', 12, 'bold'))
        txt_fname.grid(row=1, column=1, padx=2, pady=7)
#lname
        lbl_lname = Label(upper_frame, text="Last Name", font=('Arial', 12, 'bold'), fg='black')
        lbl_lname.grid(row=2, column=0, padx=2, sticky=W)

        txt_lname = ttk.Entry(upper_frame,textvariable=self.var_lname, font=('Arial', 12, 'bold'))
        txt_lname.grid(row=2, column=1, padx=2, pady=7)
#dob
        lbl_DOB = Label(upper_frame, text="DOB",font=('Arial', 12, 'bold'))
        lbl_DOB.grid(row=3, column=0, padx=2, sticky=W)

        txt_DOB = ttk.Entry(upper_frame, textvariable=self.var_dob, font=('Arial', 12, 'bold'))
        txt_DOB.grid(row=3, column=1, padx=2, pady=7)
#email
        lbl_email = Label(upper_frame, text="Email", font=('Arial', 12, 'bold'), fg='black')
        lbl_email.grid(row=4, column=0, padx=2, sticky=W)

        txt_email = ttk.Entry(upper_frame,textvariable=self.var_email, font=('Arial', 12, 'bold'))
        txt_email.grid(row=4, column=1, padx=2, pady=7)
#doj
        lbl_doj = Label(upper_frame, text="Hire Date", font=('Arial', 12, 'bold'), fg='black')
        lbl_doj.grid(row=0, column=2, padx=2, sticky=W)

        txt_doj = ttk.Entry(upper_frame, textvariable=self.var_doj ,font=('Arial', 12, 'bold'))
        txt_doj.grid(row=0, column=3, padx=2, pady=7)


        #phoneno


        lbl_phoneno = Label(upper_frame, text="Phone no. ", font=('Arial', 12, 'bold'), fg='black')
        lbl_phoneno.grid(row=1, column=2, padx=2, sticky=W)

        txt_phoneno = ttk.Entry(upper_frame,textvariable=self.var_phoneno, font=('Arial', 12, 'bold'))
        txt_phoneno.grid(row=1, column=3, padx=2, pady=7)

        # salary

        lbl_salary = Label(upper_frame, text="Salary", font=('Arial', 12, 'bold'), fg='black')
        lbl_salary.grid(row=2, column=2, padx=2, sticky=W)

        txt_salary = ttk.Entry(upper_frame,textvariable=self.var_salary, font=('Arial', 12, 'bold'))
        txt_salary.grid(row=2, column=3, padx=4, pady=7)
        #gender
        lbl_gender = Label(upper_frame, text="Gender", font=('Arial', 12, 'bold'), fg='black')
        lbl_gender.grid(row=3, column=2, padx=2, sticky=W)

        txt_gender = ttk.Entry(upper_frame, textvariable=self.var_gender,font=('Arial', 12, 'bold'))
        txt_gender.grid(row=3, column=3, padx=4, pady=7)
#lable heading
        lbl_head1 = Label(upper_frame, text="Department Details : ", font=('Arial', 13, 'bold'), fg='RED')
        lbl_head1.grid(row=0, column=4, padx=2, sticky=W)

        # dep
        lbl_dept = Label(upper_frame, text="Department", font=('Arial', 12, 'bold'), fg='black')
        lbl_dept.grid(row=1, column=4, padx=2, sticky=W)

        combo_dept = ttk.Combobox(upper_frame,textvariable=self.var_dep,font=('Arial', 12, 'bold'), width=17, state="readonly")
        combo_dept['value'] = (
        'Select Department', 'HR', 'Software Engg.', 'Assistant Manager', 'Manager', 'Data Analytics')
        combo_dept.current(0)
        combo_dept.grid(row=1, column=5, padx=2, pady=10, sticky=W)
        #did
        lbl_did = Label(upper_frame, text="Dept-id", font=('Arial', 12, 'bold'), fg='black')
        lbl_did.grid(row=2, column=4, padx=2, sticky=W)

        txt_did = ttk.Entry(upper_frame,textvariable=self.var_did, font=('Arial', 12, 'bold'))
        txt_did.grid(row=2, column=5, padx=2, pady=7)

    # lable heading
        lbl_head1 = Label(upper_frame, text="Employee Personal Details : ", font=('Arial', 13, 'bold'), fg='RED')
        lbl_head1.grid(row=3, column=4, padx=2, sticky=W)
        # AAdhar
        lbl_aadhar = Label(upper_frame, text="Aadhar No.", font=('Arial', 12, 'bold'), fg='black')
        lbl_aadhar.grid(row=4, column=4, padx=2, sticky=W)

        txt_aadhar = ttk.Entry(upper_frame, textvariable=self.var_aadharno,font=('Arial', 12, 'bold'))
        txt_aadhar.grid(row=4, column=5, padx=2, pady=7)
        #address

        lbl_address = Label(upper_frame, text="Address ", font=('Arial', 12, 'bold'), fg='black')
        lbl_address.grid(row=5, column=4, padx=2, sticky=W)

        txt_address = ttk.Entry(upper_frame,textvariable=self.var_address, font=('Arial', 12, 'bold'))
        txt_address.grid(row=5, column=5, padx=2, pady=7)

        #image in upper lable

        img_4 = Image.open('/Users/ambikamalhotra/PycharmProjects/EmployeeMS/pp.png')
        img_4 = img_4.resize((220, 220), Image.ANTIALIAS)
        self.photo_4 = ImageTk.PhotoImage(img_4)

        self.pic4 = Label(upper_frame, image=self.photo_4)
        self.pic4.place(x=920, y=0, width=220, height=220)
#buttons frame

        Button_frame = Frame(upper_frame, bd=2, relief=RIDGE, bg='white')
        Button_frame.place(x=1150, y=10, width=130, height=200)

        btn_add1=Button(Button_frame,text="Save",command=self.add_data,font=('Arial', 15, 'bold'),width=13,background='blue',fg='blue')
        btn_add1.grid(row=0,column=0,padx=1,pady=10)

        btn_add2 = Button(Button_frame, text="Update",command=self.update_data,font=('Arial', 15, 'bold'), width=13, background='blue', fg='blue')
        btn_add2.grid(row=1, column=0, padx=1, pady=10)

        btn_add3 = Button(Button_frame, text="Delete",command=self.delete_data,font=('Arial', 15, 'bold'), width=13, background='blue', fg='blue')
        btn_add3.grid(row=2, column=0, padx=1, pady=10)

        btn_add4 = Button(Button_frame, text="Clear",command=self.reset_data, font=('Arial', 15, 'bold'), width=13, background='blue', fg='blue')
        btn_add4.grid(row=3, column=0, padx=1, pady=10)

        # downframe
        down_frame = LabelFrame(Main_frame, bd=2, relief=RIDGE, bg='white', text="Employee Information Table",
                                 font=('times new roman', 12, 'bold'), fg='red')
        down_frame.place(x=10, y=270, width=1375, height=280)

        # search frame:
        search_frame = LabelFrame(down_frame, bd=2, relief=RIDGE, bg='white',text="Search Details",
                                font=('times new roman', 12, 'bold'), fg='red')
        search_frame.place(x=7, y=0, width=1350, height=60)

        search_by=Label(search_frame, font=('times new roman', 14, 'bold'),text="Search By:")
        search_by.grid(row=0,column=0,sticky=W,padx=5)

        self.var_com_search=StringVar()
        com_txt_search=ttk.Combobox(search_frame,textvariable=self.var_com_search,state="readonly",font=('times new roman', 12, 'bold'),width=18)
        com_txt_search['value']=("Select Option","Phone No","Aadhar No","Eid","Did")
        com_txt_search.current(0)
        com_txt_search.grid(row=0,column=1,sticky=W,padx=5)

        self.var_search=StringVar()
        txt_search = ttk.Entry(search_frame,textvariable=self.var_search,font=('Arial', 12, 'bold'),width=22)
        txt_search.grid(row=0, column=2, padx=5)

        btn_search = Button(search_frame,command=self.search_data,text="Search", font=('Arial', 15, 'bold'), width=13, background='blue',
                          fg='blue',border=2)
        btn_search.grid(row=0, column=3, padx=5)

        btn_Show_all = Button(search_frame,command=self.fetch_data,text="Show All", font=('Arial', 15, 'bold'), width=13, background='blue',
                            fg='blue', border=2)
        btn_Show_all.grid(row=0, column=4, padx=5)

        # employee table:

        table_frame = Frame(down_frame, bd=2, relief=RIDGE, bg='white')
        table_frame.place(x=7, y=62, width=1350, height=190)

        scroll_x = ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_frame,orient=VERTICAL)

        self.employee_table=ttk.Treeview(table_frame,column=("eid","fname","lname","dob","email","doj","phoneno","salary","gender","aadharno","address",)
                                        ,xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.employee_table.xview)
        scroll_y.config(command=self.employee_table.yview)

        self.employee_table.heading('eid',text="Emp-ID")
        self.employee_table.heading('fname', text="Fname")
        self.employee_table.heading('lname', text="Lname")
        self.employee_table.heading('dob', text="DOB")
        self.employee_table.heading('email', text="Email")
        self.employee_table.heading('doj', text="DOJ")
        self.employee_table.heading('phoneno', text="Phone No.")
        self.employee_table.heading('salary', text="Salary")
        self.employee_table.heading('gender', text="Gender")
        self.employee_table.heading('aadharno', text="Aadhar No.")
        self.employee_table.heading('address', text="Address")
        #self.employee_table.heading('did', text="Dept-ID")
        #self.employee_table.heading('dep', text="Department")

        self.employee_table['show']='headings'
        self.employee_table.column("eid",width=100)
        self.employee_table.column("fname", width=100)
        self.employee_table.column("lname", width=100)
        self.employee_table.column("dob", width=100)
        self.employee_table.column("email", width=100)
        self.employee_table.column("doj", width=100)
        self.employee_table.column("phoneno", width=100)
        self.employee_table.column("salary", width=100)
        self.employee_table.column("gender", width=100)
        self.employee_table.column("aadharno", width=100)
        #self.employee_table.column("did", width=100)
        #self.employee_table.column("dep", width=100)
        self.employee_table.column("address", width=100)







        self.employee_table.pack(fill=BOTH,expand=1)
        self.employee_table.bind("<ButtonRelease>",self.get_cursor)
        self.fetch_data()



    #functions dec for storing

    def add_data(self):
        if self.var_dep.get()=="" or self.var_email.get()=="":
            messagebox.showerror('Error','All Fields Are required')
        else:
            try:
                conn1=mysql.connector.connect(host='localhost',username='root',password='nonu1212',database='EMS')
                my_cursor1=conn1.cursor()
                my_cursor1.execute('insert into employee values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',(
                                self.var_eid.get(),
                                self.var_fname.get(),
                                self.var_lname .get(),
                                self.var_dob.get(),
                                self.var_email .get(),
                                self.var_doj.get(),
                                self.var_phoneno .get(),
                                self.var_salary .get(),
                                self.var_gender.get(),
                                self.var_aadharno .get(),
                                self.var_address .get()

                ))
                conn1.commit()
                conn1.close()

                conn2 = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')


                my_cursor2=conn2.cursor();
                my_cursor2.execute('insert into department values(%s,%s,%s)',(
                    self.var_did.get(),
                    self.var_eid.get(),
                    self.var_dep.get(),
                ))

                conn2.commit()
                self.fetch_data()
                conn2.close()

                messagebox.showinfo("Success","Employee data Added!",parent=self.root)
            except Exception as es:
                messagebox.showerror('Error',f'Due To : {str(es)}',parent=self.root)
    #fetch data

    def fetch_data(self):
        conn1 = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')

        my_cursor1 = conn1.cursor()

        my_cursor1.execute('select * from employee')

        data1=my_cursor1.fetchall()

        if len(data1) != 0:
            self.employee_table.delete(*self.employee_table.get_children())
            for i in data1:
                self.employee_table.insert("",END,values=i)

        conn1.commit()
        conn1.close()

    def get_cursor(self,event=""):
        cursor_row=self.employee_table.focus()
        content=self.employee_table.item(cursor_row)
        data=content['values']

        self.var_eid.set(data[0])
        self.var_fname.set(data[1])
        self.var_lname.set(data[2])
        self.var_dob.set(data[3])
        self.var_email.set(data[4])
        self.var_doj.set(data[5])
        self.var_phoneno.set(data[6])
        self.var_salary.set(data[7])
        self.var_gender.set(data[8])
        self.var_aadharno.set(data[9])
        self.var_address.set(data[10])


    def update_data(self):
        if self.var_dep.get()=="" or self.var_email.get()=="":
            messagebox.showerror('Error','All Fields Are required')
        else:
            try:
                update=messagebox.askyesno('Update','Are you sure to update employee date')
                if update>0:
                    conn = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')
                    my_cursor = conn.cursor()
                    my_cursor.execute('update employee set ,Eid=%s,Fname=%s,Lname=%s,DOB=%s,Email=%s,DOJ=%s,Phone No=%s,Salary=%s,Gender=%s,Aadhar No=%s,Address=%s where Eid=%s',(


                        self.var_fname.get(),
                        self.var_lname.get(),
                        self.var_dob.get(),
                        self.var_email.get(),
                        self.var_doj.get(),
                        self.var_phoneno.get(),
                        self.var_salary.get(),
                        self.var_gender.get(),
                        self.var_aadharno.get(),
                        self.var_address.get(),
                        self.var_eid.get(),

                    ))
                else:
                    if not update:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","Emplyoee successfully updated !",parent=self.root)
            except Exception as es:
                messagebox.showerror('Error', f'Due To : {str(es)}', parent=self.root)
    #delete
    def delete_data(self):
        if self.var_eid.get()=="":
            messagebox.showerror("error","All fields are required")
        else:
            try:
                delete=messagebox.askyesno("Delete","Do you realywant to delete ?")
                if delete>0:
                    conn = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')
                    my_cursor = conn.cursor()
                    sql='delete from employee where Aadhar No=%s'
                    value=(self.var_aadharno.get(),)
                    my_cursor.execute(sql,value)
                else:
                    if not delete:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success", "Emplyoee successfully deleted !", parent=self.root)
            except Exception as es:
                messagebox.showerror('Error', f'Due To : {str(es)}', parent=self.root)

                #abhi updaet and delete wale command run nhi kr rhe h yeh sab dekhe gai. yaa to foreign key relation hatao ya toh naya table banao jismai fo
                #foreign key wala constrainsts n ho yeh abhi delete ya update nhi ho rha bas .. on delete cascade chala skte h agar ata ho sahi se.

    #reset

    def reset_data(self):
        self.var_eid.set("")
        self.var_fname.set("")
        self.var_lname.set("")
        self.var_dob.set("")
        self.var_email.set("")
        self.var_doj.set("")
        self.var_phoneno.set("")
        self.var_salary.set("")
        self.var_gender.set("")
        self.var_aadharno.set("")
        self.var_address.set("")

    #search

    def search_data(self):
        if self.var_com_search.get()=='' or self.var_search.get()=="":
            messagebox.showerror("Error","Please select option")
        else:
            try:
                conn = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')
                my_cursor = conn.cursor()

                my_cursor.execute('select * from employee where ' +str(self.var_com_search.get())+" LIKE '%"+str(self.var_search.get()+"%'"))
                rows=my_cursor.fetchall()
                if len(rows) != 0:
                    self.employee_table.delete(*self.employee_table.get_children())
                    for i in rows:
                        self.employee_table.insert("",END,values=i)
                conn.commit()
                conn.close()
            except Exception as es:
                messagebox.showerror('Error', f'Due To : {str(es)}', parent=self.root)
        if self.var_com_search.get()=='' or self.var_search.get()=="":
            messagebox.showerror("Error","Please select option")
        else:
            try:
                conn1 = mysql.connector.connect(host='localhost', username='root', password='nonu1212', database='EMS')
                my_cursor1 = conn1.cursor()

                my_cursor1.execute('select * from department where ' +str(self.var_com_search.get())+" LIKE '%"+str(self.var_search.get()+"%'"))
                rows=my_cursor1.fetchall()
                if len(rows) != 0:
                    self.employee_table.delete(*self.employee_table.get_children())
                    for i in rows:
                        self.employee_table.insert("",END,values=i)
                conn1.commit()
                conn1.close()
            except Exception as es:
                messagebox.showerror('Error', f'Due To : {str(es)}', parent=self.root)























if __name__=="__main__":
    root=Tk()
    obj=Employee(root)
    root.mainloop()
